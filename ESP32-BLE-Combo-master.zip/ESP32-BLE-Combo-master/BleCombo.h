#ifndef ESP32_BLE_KEYBOARD_H
#define ESP32_BLE_KEYBOARD_H
#include "sdkconfig.h"
#if defined(CONFIG_BT_ENABLED)

#if defined(USE_NIMBLE)

#include "NimBLECharacteristic.h"
#include "NimBLEHIDDevice.h"

#define BLEDevice NimBLEDevice
#define BLEServerCallbacks NimBLEServerCallbacks
#define BLECharacteristicCallbacks NimBLECharacteristicCallbacks
#define BLEHIDDevice NimBLEHIDDevice
#define BLECharacteristic NimBLECharacteristic
#define BLEAdvertising NimBLEAdvertising
#define BLEServer NimBLEServer

#else

#include "BLEHIDDevice.h"
#include "BLECharacteristic.h"
#include "Print.h"

#endif // USE_NIMBLE

#define BLE_KEYBOARD_VERSION "0.0.4"
#define BLE_KEYBOARD_VERSION_MAJOR 0
#define BLE_KEYBOARD_VERSION_MINOR 0
#define BLE_KEYBOARD_VERSION_REVISION 4
//
#define MOUSE_LEFT 1
#define MOUSE_RIGHT 2
#define MOUSE_MIDDLE 4
#define MOUSE_BACK 8
#define MOUSE_FORWARD 16
#define MOUSE_ALL (MOUSE_LEFT | MOUSE_RIGHT | MOUSE_MIDDLE)
#define MOUSE_ALL_ALL (MOUSE_ALL | MOUSE_BACK | MOUSE_FORWARD)
//
typedef uint8_t MediaKeyReport[2];
//
const uint8_t KEY_LEFT_CTRL = 0x80;
const uint8_t KEY_LEFT_SHIFT = 0x81;
const uint8_t KEY_LEFT_ALT = 0x82;
const uint8_t KEY_LEFT_GUI = 0x83;
const uint8_t KEY_RIGHT_CTRL = 0x84;
const uint8_t KEY_RIGHT_SHIFT = 0x85;
const uint8_t KEY_RIGHT_ALT = 0x86;
const uint8_t KEY_RIGHT_GUI = 0x87;

const uint8_t KEY_A = 0x8C;
const uint8_t KEY_B = 0x8D;
const uint8_t KEY_C = 0x8E;
const uint8_t KEY_D = 0x8F;
const uint8_t KEY_E = 0x90;
const uint8_t KEY_F = 0x91;
const uint8_t KEY_G = 0x92;
const uint8_t KEY_H = 0x93;
const uint8_t KEY_I = 0x94;
const uint8_t KEY_J = 0x95;
const uint8_t KEY_K = 0x96;
const uint8_t KEY_L = 0x97;
const uint8_t KEY_M = 0x98;
const uint8_t KEY_N = 0x99;
const uint8_t KEY_O = 0x9A;
const uint8_t KEY_P = 0x9B;
const uint8_t KEY_Q = 0x9C;
const uint8_t KEY_R = 0x9D;
const uint8_t KEY_S = 0x9E;
const uint8_t KEY_T = 0x9F;
const uint8_t KEY_U = 0xA0;
const uint8_t KEY_V = 0xA1;
const uint8_t KEY_W = 0xA2;
const uint8_t KEY_X = 0xA3;
const uint8_t KEY_Y = 0xA4;
const uint8_t KEY_Z = 0xA5;

const uint8_t KEY_1 = 0xA6;
const uint8_t KEY_2 = 0xA7;
const uint8_t KEY_3 = 0xA8;
const uint8_t KEY_4 = 0xA9;
const uint8_t KEY_5 = 0xAA;
const uint8_t KEY_6 = 0xAB;
const uint8_t KEY_7 = 0xAC;
const uint8_t KEY_8 = 0xAD;
const uint8_t KEY_9 = 0xAE;
const uint8_t KEY_0 = 0xAF;

const uint8_t KEY_RETURN = 0xB0;
const uint8_t KEY_ESC = 0xB1;
const uint8_t KEY_BACKSPACE = 0xB2;
const uint8_t KEY_TAB = 0xB3;
const uint8_t KEY_SPACE = 0xB4;
const uint8_t KEY_MINUS = 0xB5;
const uint8_t KEY_EQUAL = 0xB6;
const uint8_t KEY_BRACKET_LEFT = 0xB7;
const uint8_t KEY_BRACKET_RIGHT = 0xB8;
const uint8_t KEY_BACKSLASH = 0xB9;
const uint8_t KEY_SEMICOLON = 0xBB;
const uint8_t KEY_QUOTE = 0xBC;
const uint8_t KEY_TILDE = 0xBD;
const uint8_t KEY_COMMA = 0xBE;
const uint8_t KEY_PERIOD = 0xBF;
const uint8_t KEY_SLASH = 0xC0;
const uint8_t KEY_CAPS_LOCK = 0xC1;
const uint8_t KEY_F1 = 0xC2;
const uint8_t KEY_F2 = 0xC3;
const uint8_t KEY_F3 = 0xC4;
const uint8_t KEY_F4 = 0xC5;
const uint8_t KEY_F5 = 0xC6;
const uint8_t KEY_F6 = 0xC7;
const uint8_t KEY_F7 = 0xC8;
const uint8_t KEY_F8 = 0xC9;
const uint8_t KEY_F9 = 0xCA;
const uint8_t KEY_F10 = 0xCB;
const uint8_t KEY_F11 = 0xCC;
const uint8_t KEY_F12 = 0xCD;
const uint8_t KEY_PRINTSCREEN = 0xCE;
const uint8_t KEY_SCROLL_LOCK = 0xCF;
const uint8_t KEY_PAUSE = 0xD0;
const uint8_t KEY_INSERT = 0xD1;
const uint8_t KEY_HOME = 0xD2;
const uint8_t KEY_PAGE_UP = 0xD3;
const uint8_t KEY_DELETE = 0xD4;
const uint8_t KEY_END = 0xD5;
const uint8_t KEY_PAGE_DOWN = 0xD6;
const uint8_t KEY_RIGHT_ARROW = 0xD7;
const uint8_t KEY_LEFT_ARROW = 0xD8;
const uint8_t KEY_DOWN_ARROW = 0xD9;
const uint8_t KEY_UP_ARROW = 0xDA;
const uint8_t KEY_NUM_LOCK = 0xDB;
const uint8_t KEYPAD_DIVIDE = 0xDC;
const uint8_t KEYPAD_MULTIPLY = 0xDD;
const uint8_t KEYPAD_SUBTRACT = 0xDE;
const uint8_t KEYPAD_ADD = 0xDF;
const uint8_t KEYPAD_ENTER = 0xE0;
const uint8_t KEYPAD_1 = 0xE1;
const uint8_t KEYPAD_2 = 0xE2;
const uint8_t KEYPAD_3 = 0xE3;
const uint8_t KEYPAD_4 = 0xE4;
const uint8_t KEYPAD_5 = 0xE5;
const uint8_t KEYPAD_6 = 0xE6;
const uint8_t KEYPAD_7 = 0xE7;
const uint8_t KEYPAD_8 = 0xE8;
const uint8_t KEYPAD_9 = 0xE9;
const uint8_t KEYPAD_0 = 0xEA;
const uint8_t KEYPAD_DOT = 0xEB;
const uint8_t KEY_APPLICATION = 0xED;
const uint8_t KEY_F13 = 0xF0;
const uint8_t KEY_F14 = 0xF1;
const uint8_t KEY_F15 = 0xF2;
const uint8_t KEY_F16 = 0xF3;
const uint8_t KEY_F17 = 0xF4;
const uint8_t KEY_F18 = 0xF5;
const uint8_t KEY_F19 = 0xF6;
const uint8_t KEY_F20 = 0xF7;
const uint8_t KEY_F21 = 0xF8;
const uint8_t KEY_F22 = 0xF9;
const uint8_t KEY_F23 = 0xFA;
const uint8_t KEY_F24 = 0xFB;
//
const MediaKeyReport KEY_MEDIA_NEXT_TRACK = {1, 0};
const MediaKeyReport KEY_MEDIA_PREVIOUS_TRACK = {2, 0};
const MediaKeyReport KEY_MEDIA_STOP = {4, 0};
const MediaKeyReport KEY_MEDIA_PLAY_PAUSE = {8, 0};
const MediaKeyReport KEY_MEDIA_MUTE = {16, 0};
const MediaKeyReport KEY_MEDIA_VOLUME_UP = {32, 0};
const MediaKeyReport KEY_MEDIA_VOLUME_DOWN = {64, 0};
const MediaKeyReport KEY_MEDIA_WWW_HOME = {128, 0};
const MediaKeyReport KEY_MEDIA_LOCAL_MACHINE_BROWSER = {0, 1}; // Opens "My Computer" on Windows
const MediaKeyReport KEY_MEDIA_CALCULATOR = {0, 2};
const MediaKeyReport KEY_MEDIA_WWW_BOOKMARKS = {0, 4};
const MediaKeyReport KEY_MEDIA_WWW_SEARCH = {0, 8};
const MediaKeyReport KEY_MEDIA_WWW_STOP = {0, 16};
const MediaKeyReport KEY_MEDIA_WWW_BACK = {0, 32};
const MediaKeyReport KEY_MEDIA_CONSUMER_CONTROL_CONFIGURATION = {0, 64}; // Media Selection
const MediaKeyReport KEY_MEDIA_EMAIL_READER = {0, 128};

//  Low level key report: up to 6 keys and shift, ctrl etc at once
typedef struct
{
  uint8_t modifiers;
  uint8_t reserved;
  uint8_t keys[6];
} KeyReport;

class Mouse_;
class Keyboard_;
class Gamepad_;

class BleCombo : public Print, public BLEServerCallbacks, public BLECharacteristicCallbacks
{
  friend class Mouse_;
  friend class Keyboard_;
  friend class Gamepad_;

private:
  uint8_t _buttons;
  uint8_t _buttonsGamepad[16]; // 2x64 -> 128 bytes) [0: 0-64, 1->64-128]
  BLEHIDDevice *hid;
  BLECharacteristic *inputKeyboard;
  BLECharacteristic *outputKeyboard;
  BLECharacteristic *inputMediaKeys;
  BLECharacteristic *inputMouse;
  BLECharacteristic *outputMouse;
  BLECharacteristic *inputGamepad;
  BLECharacteristic *outputGamepad;

  BLEAdvertising *advertising;
  KeyReport _keyReport;
  MediaKeyReport _mediaKeyReport;
  //std::string deviceName;
  String deviceName;
  std::string deviceManufacturer;
  uint8_t batteryLevel;
  bool connected = false;
  uint32_t _delay_ms = 7;
  void delay_ms(uint64_t ms);
  void buttons(const uint16_t b);

  uint16_t vid = 0x05ac;
  uint16_t pid = 0x820a;
  uint16_t version = 0x0210;

  static bool isInitialized;

public:
  BleCombo(/*std::string*/ String deviceName = "BL-Combo (KMG)", std::string deviceManufacturer = "JMCResearch.com", uint8_t batteryLevel = 100);
  void setBatteryLevel(uint8_t level);
  void setName(/*std::string*/String deviceName);
  void setDelay(uint32_t ms);
  bool isConnected(void);

public:
  void begin(void);
  void end(void);
  void sendReport(KeyReport *keys);
  void sendReport(MediaKeyReport *keys);
  size_t press(uint8_t k);
  size_t press(const MediaKeyReport k);
  size_t pressMouse(const uint16_t b);
  size_t release(uint8_t k);
  size_t release(const MediaKeyReport k);
  size_t releaseMouse(const uint16_t b);
  size_t write(uint8_t c);
  size_t write(const MediaKeyReport c);
  size_t write(const uint8_t *buffer, size_t size);
  void releaseAll(void);

  // keypad magic
  void resetButtons();
  void setAxes(int16_t x, int16_t y, int16_t a1, int16_t a2, int16_t a3, int16_t a4, int16_t a5, int16_t a6, signed char hat1, signed char hat2, signed char hat3, signed char hat4);
  size_t pressButton(uint8_t b);
  size_t releaseButton(uint8_t b);
  bool isPressedButton(uint8_t b);

  void click(const uint16_t b);
  void move(signed char x, signed char y, signed char wheel = 0, signed char hWheel = 0);
  void wheel(signed char wheel = 0, signed char hWheel = 0);
  bool isPressed(const uint16_t b);
protected:
  void set_vendor_id(uint16_t vid);
  void set_product_id(uint16_t pid);
  void set_version(uint16_t version);
  virtual void onStarted(BLEServer *pServer){};
  virtual void onConnect(BLEServer *pServer) override;
  virtual void onDisconnect(BLEServer *pServer) override;
  virtual void onWrite(BLECharacteristic *me) override;
};

extern BleCombo bleDevice;
#endif // CONFIG_BT_ENABLED
#endif // ESP32_BLE_KEYBOARD_H
